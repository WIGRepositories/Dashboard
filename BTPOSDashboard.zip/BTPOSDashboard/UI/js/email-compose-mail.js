$(function () {
    //BEGIN BOOTSTRAP WYSIWYG5
    $('.wysihtml5').wysihtml5();
    //END BOOTSTRAP WYSIWYG5

});
