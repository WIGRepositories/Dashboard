create procedure [dbo].[getRegistrationBTPOS]
as
begin
select * from RegistrationBTPOS
end
