$(function () {
    $('.mix-grid').mixItUp();
});